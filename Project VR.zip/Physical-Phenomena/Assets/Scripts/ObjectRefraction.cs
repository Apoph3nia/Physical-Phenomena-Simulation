using UnityEngine;
using System.Text;
using TMPro;

public class ObjectRefraction : MonoBehaviour
{
    [Header("References")]
    public WaterPhysics waterPhysics;               // Reference to the WaterPhysics script to get water level.

    [Header("Optical Properties")]
    [Range(1.0f, 2.0f)]
    public float indexOfRefractionAir = 1.0f;       // Refractive index of the medium the object is mostly in (air).
    [Range(1.0f, 2.0f)]
    public float indexOfRefractionWater = 1.33f;    // Refractive index of the water.

    [Header("Physical Properties")]
    public float objLength = 10f;                   // The total length of the object.

    [Header("UI Debug Panel")]
    public TextMeshProUGUI debugPanelText;   // assign in Inspector

    [Header("Debug Info")]
    [HideInInspector] public Vector3 IntersectionPoint; // Point where the object intersects the water surface.
    [HideInInspector] public float IncidentAngle;       // Angle of incidence at the intersection point.
    [HideInInspector] public float RefractedAngle;      // Angle of refraction at the intersection point.
    [HideInInspector] public bool HasIntersection;      // Flag indicating if the object is intersecting with the water.

    private Vector3 refractedDirection;             // Direction of the object after refraction.
    private float objDistance;                      // Distance from the object's origin to the water intersection point.

    void Update()
    {
        if (waterPhysics == null)
        {
            HasIntersection = false;

            if (debugPanelText != null)
                debugPanelText.text = "No water intersection";

            return;
        }

        float waterY = waterPhysics.WaterSurfaceY;
        Vector3 waterNormal = Vector3.up;
        Vector3 objPos = transform.position;
        Vector3 objDir = -transform.up;

        Plane waterPlane = new Plane(waterNormal, new Vector3(0, waterY, 0));
        HasIntersection = false;

        if (waterPlane.Raycast(new Ray(objPos, objDir), out objDistance) && objDistance <= objLength)
        {
            HasIntersection = true;
            IntersectionPoint = objPos + objDir * objDistance;

            if (RefractionUtils.TryRefract(objDir, waterNormal, indexOfRefractionAir, indexOfRefractionWater, out refractedDirection))
            {
                IncidentAngle = Vector3.Angle(objDir, -waterNormal);
                RefractedAngle = Vector3.Angle(refractedDirection, -waterNormal);
            }
            else
            {
                refractedDirection = objDir;
                IncidentAngle = Vector3.Angle(objDir, -waterNormal);
                RefractedAngle = 0f;
            }
        }

        // 🔹 Always refresh the panel
        if (debugPanelText != null)
        {
            debugPanelText.text = BuildDebugPanelString();
        }
    }

    // Build a formatted debug string for the panel
    public string BuildDebugPanelString()
    {
        string cyanHex    = "#00FFFF";
        string yellowHex  = "#FFFF00";

        StringBuilder sb = new StringBuilder();

        if (HasIntersection)
        {
            sb.AppendLine("<b>OBJECT REFRACTION</b>");
            sb.AppendLine($"Intersection: {IntersectionPoint:F3}");

            sb.AppendLine($"i: <color={cyanHex}>{IncidentAngle:F1}°</color>  " +    // cyan
                          $"r: <color={yellowHex}>{RefractedAngle:F1}°</color>");   // yellow

            sb.AppendLine(RefractionUtils.FormatSnellsLaw(indexOfRefractionAir, IncidentAngle, indexOfRefractionWater, RefractedAngle, cyanHex, yellowHex));
        }
        else
        {
            sb.AppendLine("No water intersection");
        }

        return sb.ToString();
    }
}