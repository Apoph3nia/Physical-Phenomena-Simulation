using UnityEngine;
using UnityEngine.UI;

public class SimSelect : MonoBehaviour
{
    public Image panel1;
    public Image panel2;

    public Color SimColor1 = new Color(0f, 0.5527f, 1f, 1f);
    public Color SimColor2 = new Color(0f, 1f, 0.3725f, 1f);

    public void SelectSim1()
    {
        panel1.color = SimColor2;
        panel2.color = SimColor1;
    }

    public void SelectSim2()
    {
        panel1.color = SimColor1;
        panel2.color = SimColor2;
    }
}
