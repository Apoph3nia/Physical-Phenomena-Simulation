using UnityEngine;
using System.Collections.Generic;

public class ObjectRefraction : MonoBehaviour
{
    [Header("References")]
    public WaterPhysics waterPhysics;               // Reference to the WaterPhysics script to get water level.

    [Header("Optical Properties")]
    [Range(1.0f, 2.0f)]
    public float indexOfRefractionAir = 1.0f;       // Refractive index of the medium the object is mostly in (air).
    [Range(1.0f, 2.0f)]
    public float indexOfRefractionWater = 1.33f;    // Refractive index of the water.

    [Header("Physical Properties")]
    public float objLength = 10f;                 // The total length of the object.

    [Header("Debug Info")]
    [HideInInspector] public Vector3 IntersectionPoint;    // Point where the object intersects the water surface.
    [HideInInspector] public float IncidentAngle;          // Angle of incidence at the intersection point.
    [HideInInspector] public float RefractedAngle;         // Angle of refraction at the intersection point.
    [HideInInspector] public bool HasIntersection;         // Flag indicating if the object is intersecting with the water.

    private Vector3 refractedDirection;             // Direction of the object after refraction.
    private float objDistance;                    // Distance from the object's origin to the water intersection point.

    // runtime-populated list of world-space labels (position, text, color)
    private List<(Vector3, string, Color)> _worldLabels = new List<(Vector3, string, Color)>();

    void Update()
    {
        // If there's no reference to the water physics, do nothing.
        if (waterPhysics == null)
        {
            HasIntersection = false;
            _worldLabels.Clear();
            return;
        }

        // Get water surface properties from the WaterPhysics script.
        float waterY = waterPhysics.WaterSurfaceY;
        Vector3 waterNormal = Vector3.up;           // Assuming the water surface is always horizontal.
        Vector3 objPos = transform.position;      // Current position of the object's top.
        Vector3 objDir = -transform.up;           // Direction the object is pointing, assuming it's oriented with -Y as down.

        // Define the water surface as a plane.
        Plane waterPlane = new Plane(waterNormal, new Vector3(0, waterY, 0));

        // By default, assume no intersection.
        HasIntersection = false;

        // Check if the ray cast from the object intersects with the water plane within the object's length.
        if (waterPlane.Raycast(new Ray(objPos, objDir), out objDistance) && objDistance <= objLength)
        {
            HasIntersection = true;
            // Calculate the exact point of intersection.
            IntersectionPoint = objPos + objDir * objDistance;

            // Try to calculate the refracted direction of the object in the water.
            if (RefractionUtils.TryRefract(objDir, waterNormal, indexOfRefractionAir, indexOfRefractionWater, out refractedDirection))
            {
                // If refraction is successful, calculate and store the incident and refracted angles for debugging.
                IncidentAngle = Vector3.Angle(objDir, -waterNormal);
                RefractedAngle = Vector3.Angle(refractedDirection, -waterNormal);
            }
            else
            {
                // This case handles total internal reflection, which is unlikely for air-to-water refraction.
                // As a fallback, the object continues in the same direction without refraction.
                refractedDirection = objDir;
                IncidentAngle = Vector3.Angle(objDir, -waterNormal);
                RefractedAngle = 0f;
            }
        }

        // Populate world labels for displaying debug info in the game view.
        UpdateWorldLabels();
    }

    // Build the list of labels each frame based on current debug values.
    private void UpdateWorldLabels()
    {
        _worldLabels.Clear();

        if (!HasIntersection) return;

        // Constants for positioning the labels in world space to be readable.
        const float arcR = 0.2f;
        const float gap = 0.03f;

        // Label for Angle of Incidence (AOI)
        // Compute incident vector used for angle calculation.
        Vector3 objDir = -transform.up;
        Vector3 incidentVec = -objDir; // Vector pointing from the intersection point towards the object's origin.
        float i1 = Vector3.Angle(incidentVec, Vector3.up);
        _worldLabels.Add((IntersectionPoint + incidentVec * (arcR + gap), $"AOI: {i1:F1}°", Color.green));

        // Label for Angle of Refraction (AOR)
        Vector3 r1v = refractedDirection.normalized;
        float r1 = Vector3.Angle(r1v, -Vector3.up);
        _worldLabels.Add((IntersectionPoint + r1v * (arcR * 0.8f + gap), $"AOR: {r1:F1}°", Color.cyan));
    }

    void OnDrawGizmos()
    {
        // Do not draw gizmos if the water physics reference is not set.
        if (waterPhysics == null) return;

        Vector3 objPos = transform.position;
        Vector3 objDir = -transform.up;

        if (HasIntersection)
        {
            // Draw the part of the object that is above the water.
            Gizmos.color = Color.yellow;
            Gizmos.DrawLine(objPos, IntersectionPoint);

            // Draw the refracted part of the object that is inside the water.
            Gizmos.color = Color.red;
            Gizmos.DrawLine(IntersectionPoint, IntersectionPoint + refractedDirection * (objLength - objDistance));

#if UNITY_EDITOR
            // In the Unity Editor, draw arcs to visualize the angles of incidence and refraction.
            Vector3 incidentDir = -objDir;    // Direction towards the surface for angle visualization.
            Vector3 normal = Vector3.up;        // The normal of the water surface.

            RefractionUtils.DrawAngleArc(IntersectionPoint, incidentDir, normal, IncidentAngle, 1f, Color.green);
            RefractionUtils.DrawAngleArc(IntersectionPoint, refractedDirection, -normal, RefractedAngle, 0.8f, Color.cyan);
#endif
        }
        else
        {
            // If there is no intersection, draw the full length of the object without any refraction effect.
            Gizmos.color = Color.yellow;
            Gizmos.DrawLine(objPos, objPos + objDir * objLength);
        }
    }

    void OnGUI()
    {
        // Show a debug panel on the screen when the object intersects with the water.
        if (HasIntersection)
        {
            // Define the dimensions and position of the debug panel.
            float boxWidth = 300f;
            float boxHeight = 100f;
            float margin = 10f;

            Rect boxRect = new Rect(margin, margin, boxWidth, boxHeight);

            // Format the content to be displayed in the debug panel.
            string content = RefractionUtils.FormatAngleInfo("AOI", IncidentAngle, "AOR", RefractedAngle) + "\n";
            content += RefractionUtils.FormatSnellsLaw(indexOfRefractionAir, IncidentAngle, indexOfRefractionWater, RefractedAngle);

            // Draw the debug panel using a utility function.
            RefractionUtils.DrawDebugPanel(boxRect, "Refraction Details:", content);

            // Draw world-space labels for angles and depth.
            // This is done on Repaint events for efficiency.
            foreach (var label in _worldLabels)
            {
                RefractionUtils.DrawWorldLabel(label.Item1, label.Item2, label.Item3);
            }
        }
    }
}
