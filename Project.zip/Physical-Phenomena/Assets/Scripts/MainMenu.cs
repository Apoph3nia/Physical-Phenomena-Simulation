using UnityEngine;
using UnityEngine.SceneManagement;

public class MainMenu : MonoBehaviour
{
    private int sceneIndex = -1;

    public void SelectSim(int index)
    {
        sceneIndex = index;
    }

    public void StartSim()
    {
        if (sceneIndex != -1)
        {
            SceneManager.LoadSceneAsync(sceneIndex);
        }
    }

    public void QuitSim()
    {
        Application.Quit();
    }
}
