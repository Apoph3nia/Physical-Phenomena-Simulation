#if UNITY_EDITOR
using UnityEditor;
#endif
using UnityEngine;
using System;
using System.Collections.Generic;

/// <summary>
/// Casts a ray from this GameObject, intersects a prism mesh, refracts the ray into the prism,
/// finds the exit face, refracts (or reflects if TIR) out, and optionally draws a dispersion fan.
/// Includes a small BVH implementation for fast triangle intersection against the prism mesh.
/// Debugging helpers draw labels and gizmos both in-editor and at runtime (labels are runtime-safe).
/// </summary>
[RequireComponent(typeof(LineRenderer))]
public class PrismRaycaster : MonoBehaviour
{
    [Header("Ray Settings")]
    public float maxDistance = 5f;            // maximum ray distance for entry/exit rays
    public LayerMask prismLayer;              // physics layer used for initial physics.Raycast
    public MeshFilter prismMeshFilter;        // mesh representation of the prism (used for BVH/manual raycast)

    [Header("Prism Properties")]
    [Range(1.0f, 2.0f)]
    public float indexOfRefraction = 1.5f;    // base IOR used for refraction (middle/green light)

    [Header("Dispersion")]
    public bool  enableDispersion   = true;   // toggle to draw the spectrum fan
    [Range(0.0005f, 0.5f)]
    public float dispersionStrength = 0.1f;   // how much IOR varies across the spectrum (± half of this)
    public Material dispersionMaterial;       // optional material used for dispersion rays
    private const int dispersionRayCount = 21; // number of rays used to sample the spectrum fan

    [Header("Debug")]
    public bool enableDebug = true;           // global debug toggle (gizmos, panels)
    public bool enableDebugText = true;       // draw debug text panel (runtime only)

    // Runtime/populated labels (position, text, color). Uses tuples to be build/runtime safe.
    private List<(Vector3, string, Color)> _worldLabels = new List<(Vector3, string, Color)>();

    private LineRenderer lineRenderer;
    private const float RAY_OFFSET = 0.001f;  // small offset to avoid self-intersection when casting from hit points

    // Cached transforms last frame — used to detect movement and avoid re-computing when moving.
    private Vector3    lastSourcePos, lastPrismPos;
    private Quaternion lastSourceRot, lastPrismRot;

    // Mesh caches for the BVH (stored in mesh-local coordinates)
    private Vector3[] cachedVertices;
    private int[]   cachedTriangles;

    // Simple BVH node for accelerating triangle intersection tests
    private class BVHNode
    {
        public Bounds   bounds;
        public BVHNode  left, right;
        public int[]    triangleIndices; // indices into cachedTriangles (index points to triangle's first index)
    }
    private BVHNode bvhRoot;
    private const int BVH_LEAF_MAX_TRIANGLES = 4; // leaf threshold

    // Debug data (exposed but hidden in inspector). Populated each frame for UI/gizmos.
    [HideInInspector] public bool debugHasHit    = false;
    [HideInInspector] public bool debugHasExit   = false;
    [HideInInspector] public Vector3 debugEntryHitPoint;
    [HideInInspector] public Vector3 debugEntryNormal;
    [HideInInspector] public Vector3 debugRefractedDirection;
    [HideInInspector] public Vector3 debugExitHitPoint;
    [HideInInspector] public Vector3 debugExitNormal;
    [HideInInspector] public Vector3 debugInitialRayDirection;
    [HideInInspector] public Vector3 debugFinalRayDirection;
    [HideInInspector] public bool debugExitIsTIR = false;

    [HideInInspector] public float debugEntryAngleI1, debugEntryAngleR1;
    [HideInInspector] public float debugExitAngleI2, debugExitAngleR2;
    [HideInInspector] public float debugCriticalAngle;
    [HideInInspector] public float debugDispersionMinIOR, debugDispersionMaxIOR;

    // Simple spectrum palette (used for per-ray color in the dispersion fan)
    private readonly Color[] spectrum = {
        Color.red,
        new Color(1, 0.5f, 0),
        Color.yellow,
        Color.green,
        new Color(0, 0.5f, 1),
        Color.blue,
        new Color(.3f, 0, .8f)
    };

    // Pre-created LineRenderers for the dispersion rays and their property blocks
    private LineRenderer[] dispersionRays;
    private MaterialPropertyBlock[] dispersionPropertyBlocks;

    /// <summary>Pick an approximated color from the spectrum array based on t in [0,1].</summary>
    private Color GetSpectrumColor(float t)
    {
        int idx = Mathf.RoundToInt(t * (spectrum.Length - 1));
        return spectrum[idx];
    }

    /// <summary>
    /// Create/dispose child LineRenderers used for showing the dispersion fan.
    /// Uses a shared material instance so the property block color changes can be applied per-line efficiently.
    /// </summary>
    private void CreateDispersionRays()
    {
        // Clear any existing Ray_* children (useful when re-creating in editor)
        foreach (Transform c in transform)
            if (c.name.StartsWith("Ray_"))
                DestroyImmediate(c.gameObject);

        dispersionRays = new LineRenderer[dispersionRayCount];
        dispersionPropertyBlocks = new MaterialPropertyBlock[dispersionRayCount];
        Material template = dispersionMaterial != null ? dispersionMaterial : lineRenderer.material;
        Material sharedDispersionMaterial = new Material(template); // create instance so property blocks work predictably

        for (int i = 0; i < dispersionRayCount; i++)
        {
            var go = new GameObject("Ray_" + i);
            go.transform.SetParent(transform, false);

            var lr = go.AddComponent<LineRenderer>();
            lr.material = sharedDispersionMaterial;

            dispersionPropertyBlocks[i] = new MaterialPropertyBlock();
            Color rayColor = GetSpectrumColor((float)i / (dispersionRayCount - 1));
            // Set both color and emissive color (material must use these properties)
            dispersionPropertyBlocks[i].SetColor("_Color", rayColor);
            dispersionPropertyBlocks[i].SetColor("_EmissiveColor", rayColor);
            lr.SetPropertyBlock(dispersionPropertyBlocks[i]);

            lr.useWorldSpace   = true;
            lr.positionCount   = 3;      // default, will be overridden when drawing
            lr.numCapVertices  = 4;      // nicer end caps
            lr.enabled         = false;  // disabled until needed

            dispersionRays[i] = lr;
        }
    }

    void Awake()
    {
        lineRenderer = GetComponent<LineRenderer>();
        lineRenderer.useWorldSpace = true;
        lineRenderer.numCornerVertices = 0;

        // Cache mesh data and build BVH (used for accurate exit intersection against mesh triangles)
        if (prismMeshFilter != null)
        {
            Mesh m = prismMeshFilter.sharedMesh;
            cachedVertices  = m.vertices;
            cachedTriangles = m.triangles;
            BuildBVH();
            CreateDispersionRays();
        }

        // Initialize last-transform trackers for movement detection
        lastSourcePos = transform.position;
        lastSourceRot = transform.rotation;
        lastPrismPos  = prismMeshFilter.transform.position;
        lastPrismRot  = prismMeshFilter.transform.rotation;
    }

    void Update()
    {
        if (prismMeshFilter == null) return;

        // detect movement of source or prism to avoid drawing stale debug or dispersion rays the same frame
        Vector3    curSrcPos = transform.position;
        Quaternion curSrcRot = transform.rotation;
        Vector3    curPrsPos = prismMeshFilter.transform.position;
        Quaternion curPrsRot = prismMeshFilter.transform.rotation;

        bool moved = curSrcPos != lastSourcePos || curSrcRot != lastSourceRot ||
                     curPrsPos != lastPrismPos   || curPrsRot != lastPrismRot;

        lastSourcePos = curSrcPos;
        lastSourceRot = curSrcRot;
        lastPrismPos  = curPrsPos;
        lastPrismRot  = curPrsRot;

        if (moved)
        {
            // If the source/prism moved since last frame, disable and clear labels — the next frame will recalc.
            lineRenderer.enabled = false;
            DisableDispersionRays();
            _worldLabels.Clear();
            return;
        }

        lineRenderer.enabled = true;

        // reset debug state for this frame
        debugHasHit = debugHasExit = false;
        DisableDispersionRays();

        // 1) Cast entry ray (use Unity Physics for the initial hit detection so colliders can be used)
        Ray ray = new Ray(transform.position, transform.forward);
        debugInitialRayDirection = ray.direction;

        // If we don't hit the prism at all, draw the ray and clear labels
        if (!Physics.Raycast(ray, out var entryHit, maxDistance, prismLayer))
        {
            lineRenderer.positionCount = 2;
            lineRenderer.SetPosition(0, ray.origin);
            lineRenderer.SetPosition(1, ray.origin + ray.direction * maxDistance);

            _worldLabels.Clear();
            return;
        }

        // 2) Refract in: compute direction inside the prism using Snell's law.
        // If TryRefract returns false here it means total internal reflection at entry (rare when entering from air -> prism)
        if (!RefractionUtils.TryRefract(ray.direction, entryHit.normal, 1f, indexOfRefraction, out var refractedDir))
        {
            // draw only to entry point and skip rest
            lineRenderer.positionCount = 2;
            lineRenderer.SetPosition(0, ray.origin);
            lineRenderer.SetPosition(1, entryHit.point);

            _worldLabels.Clear();
            return;
        }

        // Store entry debug info
        debugHasHit = true;
        debugEntryHitPoint      = entryHit.point;
        debugEntryNormal        = entryHit.normal;
        debugRefractedDirection = refractedDir;

        // Calculate entry angles for display (i₁ and r₁)
        debugEntryAngleI1 = Vector3.Angle(-debugInitialRayDirection, debugEntryNormal);
        debugEntryAngleR1 = Vector3.Angle(debugRefractedDirection, -debugEntryNormal);
        
        // Calculate critical angle for the current IOR (θc = asin(n2/n1) with n2=1)
        debugCriticalAngle = Mathf.Asin(1f / indexOfRefraction) * Mathf.Rad2Deg;

        // 3) Find exit: perform a more accurate intersection (against mesh triangles) starting from slightly inside
        Ray insideRay = new Ray(entryHit.point + refractedDir * RAY_OFFSET, refractedDir);
        if (!FindExitPoint(insideRay, out var exitHit))
        {
            // If we found an entry but no exit, draw entry and the internal ray (either until hit or to maxdistance)
            lineRenderer.positionCount = 3;
            lineRenderer.SetPosition(0, ray.origin);
            lineRenderer.SetPosition(1, entryHit.point);
            if (Physics.Raycast(insideRay, out var termHit, maxDistance, prismLayer))
                lineRenderer.SetPosition(2, termHit.point);
            else
                lineRenderer.SetPosition(2, insideRay.origin + insideRay.direction * maxDistance);

            // we can't produce an exit label — update labels with what we have and return
            UpdateWorldLabels();
            return;
        }

        // 4) Refract out or detect TIR at exit:
        // Try refracting from prism -> air. If TryRefract fails, that's TIR and we compute reflection instead.
        if (!RefractionUtils.TryRefract(refractedDir, exitHit.normal, indexOfRefraction, 1f, out debugFinalRayDirection))
        {
            // If refraction fails due to TIR, reflect the ray for visualization.
            debugFinalRayDirection = Vector3.Reflect(refractedDir, exitHit.normal);
            debugExitIsTIR = true; // mark TIR
        }
        else
        {
            debugExitIsTIR = false; // ordinary refraction
        }

        // store exit debug details
        debugHasExit     = true;
        debugExitHitPoint = exitHit.point;
        debugExitNormal   = exitHit.normal;

        // calculate exit angles (i₂ always exists, r₂ only if not TIR)
        debugExitAngleI2 = Vector3.Angle(-debugRefractedDirection, debugExitNormal);
        if (!debugExitIsTIR)
        {
            debugExitAngleR2 = Vector3.Angle(debugFinalRayDirection, -debugExitNormal);
        }
        
        // dispersion range for presentation / coloring
        float nDelta = dispersionStrength * 0.5f;
        debugDispersionMinIOR = indexOfRefraction - nDelta;
        debugDispersionMaxIOR = indexOfRefraction + nDelta;

        // Ensure debugFinalRayDirection is a refracted direction when possible (some code paths above already set reflection for TIR)
        if (!RefractionUtils.TryRefract(refractedDir, exitHit.normal, indexOfRefraction, 1f, out debugFinalRayDirection))
        {
            // TIR fallback (defensive) — reflect if refraction fails
            debugFinalRayDirection = Vector3.Reflect(refractedDir, exitHit.normal);
        }

        // 5) Draw the white path (entry and internal hit + exit point)
        lineRenderer.positionCount = 3;
        lineRenderer.SetPosition(0, ray.origin);
        lineRenderer.SetPosition(1, entryHit.point);
        lineRenderer.SetPosition(2, exitHit.point);

        // 6) Draw dispersion fan (if enabled) — uses per-wavelength IOR sampling across dispersionRayCount
        if (enableDispersion)
            DrawDispersion(exitHit.point, refractedDir, exitHit.normal);

        // Populate runtime labels so they are available in builds (UpdateWorldLabels uses debug fields)
        UpdateWorldLabels();
    }

    /// <summary>
    /// Draw a fan of refracted rays at the exit point to visualize dispersion.
    /// Each ray uses a slightly different IOR sampled across the dispersion range.
    /// Rays that undergo TIR (for that wavelength) are skipped.
    /// </summary>
    private void DrawDispersion(Vector3 exitPt, Vector3 dirInside, Vector3 exitNormal)
    {
        float nDelta = dispersionStrength * 0.5f;
        float invS = 1f / (dispersionRayCount - 1);
        
        // planeNormal is the normal of the plane containing the incidence and exit directions; used to compute fan axis
        Vector3 planeNormal = Vector3.Cross(dirInside, exitNormal).normalized;
        float rayWidth = lineRenderer.startWidth;

        for (int i = 0; i < dispersionRayCount; i++)
        {
            float t = i * invS;
            // Ray IOR mapping: red=low IOR, violet=high IOR (corrected comment)
            float rayIOR = indexOfRefraction - nDelta + t * 2 * nDelta;
            
            Vector3 dirOut;
            bool isTIR = !RefractionUtils.TryRefract(dirInside, exitNormal, rayIOR, 1f, out dirOut);
            
            var lr = dispersionRays[i];
            if (isTIR || dirOut == Vector3.zero)
            {
                // If the wavelength experiences TIR at exit we don't draw it (it wouldn't exit)
                lr.enabled = false;
                continue;
            }

            // Fan spread is simulated by offsetting the start point slightly across the incidence plane
            float offset = (0.5f - t) * rayWidth;
            Vector3 right = Vector3.Cross(dirOut, planeNormal).normalized;
            Vector3 startPoint = exitPt + right * offset;

            lr.startWidth = lr.endWidth = rayWidth * 0.3f;
            lr.positionCount = 2;
            lr.SetPosition(0, startPoint);
            lr.SetPosition(1, startPoint + dirOut * maxDistance);
            lr.enabled = true;
        }
    }

    /// <summary>Disable all dispersion ray renderers (fast path for clearing visuals).</summary>
    private void DisableDispersionRays()
    {
        if (dispersionRays == null) return;
        foreach (var lr in dispersionRays)
            lr.enabled = false;
    }

    /// <summary>
    /// Manual raycast against the cached mesh BVH.
    /// Transforms the incoming world-space ray into mesh-local space, intersects the BVH,
    /// and transforms the hit back into world-space.
    /// </summary>
    private bool ManualRaycast(Ray ray, out RaycastHit hit)
    {
        hit = new RaycastHit();
        if (bvhRoot == null) return false;

        var xf = prismMeshFilter.transform;
        var local = new Ray(
            xf.InverseTransformPoint(ray.origin),
            xf.InverseTransformDirection(ray.direction)
        );

        // IntersectBVH returns the closest hit in local-space coordinates
        if (IntersectBVH(local, bvhRoot, out _, out Vector3 lp, out Vector3 ln))
        {
            hit.point    = xf.TransformPoint(lp);
            hit.normal   = xf.TransformDirection(ln);
            hit.distance = (hit.point - ray.origin).magnitude;
            // Ensure normal is oriented opposite to incoming ray (so TryRefract sees the correct side)
            if (Vector3.Dot(hit.normal, ray.direction) > 0f)
                hit.normal = -hit.normal;
            return true;
        }
        return false;
    }

    /// <summary>
    /// Find a valid exit point for a ray traveling inside the prism.
    /// Uses ManualRaycast (BVH) to find precise triangle intersections and skips a small
    /// number of near-horizontal faces to avoid getting stuck on the bottom face due to numerical issues.
    /// </summary>
    private bool FindExitPoint(Ray currentRay, out RaycastHit exitHit)
    {
        // We temporarily enable backface hits so internal faces can be detected regardless of winding.
        Physics.queriesHitBackfaces = true;
        bool didHit = ManualRaycast(currentRay, out exitHit);
        int skips = 0;
        const int MAX_SKIPS = 5;

        // Skip up to MAX_SKIPS horizontal faces (dot with world up near 1). This avoids hitting the bottom face repeatedly.
        while (didHit && skips < MAX_SKIPS && Mathf.Abs(Vector3.Dot(exitHit.normal, Vector3.up)) > 0.9f)
        {
            skips++;
            currentRay = new Ray(exitHit.point + currentRay.direction * RAY_OFFSET, currentRay.direction);
            didHit = ManualRaycast(currentRay, out exitHit);
        }
        Physics.queriesHitBackfaces = false;
        return didHit;
    }

    #region BVH & Refract helpers

    /// <summary>Prepare a list of triangle "indices" (index into cachedTriangles array) and build root BVH.</summary>
    private void BuildBVH()
    {
        var indices = new List<int>(cachedTriangles.Length / 3);
        for (int i = 0; i < cachedTriangles.Length; i += 3)
            indices.Add(i);
        bvhRoot = BuildBVHRecursive(indices);
    }

    /// <summary>Recursively split triangle indices into a BVH. Splits along longest axis at bounds center.</summary>
    private BVHNode BuildBVHRecursive(List<int> triangleIndices)
    {
        var node = new BVHNode { bounds = CalculateBounds(triangleIndices) };
        if (triangleIndices.Count <= BVH_LEAF_MAX_TRIANGLES)
        {
            node.triangleIndices = triangleIndices.ToArray();
            return node;
        }

        // Choose longest axis to split
        int axis = 0;
        if (node.bounds.size.y > node.bounds.size.x) axis = 1;
        if (node.bounds.size.z > node.bounds.size[axis]) axis = 2;
        float split = node.bounds.center[axis];

        var left  = new List<int>();
        var right = new List<int>();
        foreach (int idx in triangleIndices)
        {
            int i0 = cachedTriangles[idx];
            int i1 = cachedTriangles[idx + 1];
            int i2 = cachedTriangles[idx + 2];
            // triangle centroid along axis
            float c = (cachedVertices[i0][axis] +
                       cachedVertices[i1][axis] +
                       cachedVertices[i2][axis]) / 3f;
            if (c < split) left.Add(idx);
            else          right.Add(idx);
        }
        // If split produced empty child (degenerate), fall back to a simple half-split to avoid infinite recursion.
        if (left.Count == 0 || right.Count == 0)
        {
            int half = triangleIndices.Count / 2;
            left  = triangleIndices.GetRange(0, half);
            right = triangleIndices.GetRange(half, triangleIndices.Count - half);
        }
        node.left  = BuildBVHRecursive(left);
        node.right = BuildBVHRecursive(right);
        return node;
    }

    /// <summary>Compute axis-aligned bounds for a set of triangles (in mesh-local coordinates).</summary>
    private Bounds CalculateBounds(List<int> triangleIndices)
    {
        if (triangleIndices.Count == 0) return new Bounds();
        int idx0 = triangleIndices[0];
        var b = new Bounds(cachedVertices[cachedTriangles[idx0]], Vector3.zero);
        foreach (int idx in triangleIndices)
        {
            b.Encapsulate(cachedVertices[cachedTriangles[idx]]);
            b.Encapsulate(cachedVertices[cachedTriangles[idx + 1]]);
            b.Encapsulate(cachedVertices[cachedTriangles[idx + 2]]);
        }
        return b;
    }

    /// <summary>
    /// Intersect a ray with the BVH. If hit, returns the closest intersection (distance, point, normal) in local-space.
    /// </summary>
    private bool IntersectBVH(Ray ray, BVHNode node,
                              out float closestDistance,
                              out Vector3 hitPoint,
                              out Vector3 normal)
    {
        closestDistance = float.MaxValue;
        hitPoint = Vector3.zero;
        normal   = Vector3.zero;
        // Quick reject using bounds test
        if (!node.bounds.IntersectRay(ray)) return false;

        // Leaf node — test all triangles
        if (node.triangleIndices != null)
        {
            foreach (int idx in node.triangleIndices)
            {
                Vector3 v0 = cachedVertices[cachedTriangles[idx]];
                Vector3 v1 = cachedVertices[cachedTriangles[idx + 1]];
                Vector3 v2 = cachedVertices[cachedTriangles[idx + 2]];
                if (IntersectTriangle(ray, v0, v1, v2, out float d, out Vector3 p))
                {
                    // Ignore hits extremely close to origin (self intersection)
                    if (d > 1e-4f && d < closestDistance)
                    {
                        closestDistance = d;
                        hitPoint        = p;
                        normal          = Vector3.Cross(v1 - v0, v2 - v0).normalized;
                    }
                }
            }
            return closestDistance < float.MaxValue;
        }

        // Interior node — recurse both sides and pick the nearest hit
        bool hitL = IntersectBVH(ray, node.left,  out float ld, out Vector3 lh, out Vector3 ln);
        bool hitR = IntersectBVH(ray, node.right, out float rd, out Vector3 rh, out Vector3 rn);
        if (hitL && hitR)
        {
            if (ld < rd) { closestDistance = ld; hitPoint = lh; normal = ln; }
            else         { closestDistance = rd; hitPoint = rh; normal = rn; }
            return true;
        }
        if (hitL) { closestDistance = ld; hitPoint = lh; normal = ln; return true; }
        if (hitR) { closestDistance = rd; hitPoint = rh; normal = rn; return true; }
        return false;
    }

    /// <summary>
    /// Ray-triangle intersection using the Möller–Trumbore algorithm.
    /// Returns true if the triangle is hit and outputs the distance along the ray and the hit point.
    /// The ray and triangle are assumed to be in the same space (mesh-local in our usage).
    /// </summary>
    private bool IntersectTriangle(Ray ray,
                                   Vector3 v0, Vector3 v1, Vector3 v2,
                                   out float distance, out Vector3 hitPoint)
    {
        distance = 0f;
        hitPoint = Vector3.zero;
        const float EPS = 1e-8f;

        Vector3 e1 = v1 - v0;
        Vector3 e2 = v2 - v0;
        Vector3 p  = Vector3.Cross(ray.direction, e2);
        float det  = Vector3.Dot(e1, p);
        if (det > -EPS && det < EPS) return false; // ray parallel to triangle

        float invDet = 1f / det;
        Vector3 t    = ray.origin - v0;
        float u      = invDet * Vector3.Dot(t, p);
        if (u < 0f || u > 1f) return false;

        Vector3 q = Vector3.Cross(t, e1);
        float v   = invDet * Vector3.Dot(ray.direction, q);
        if (v < 0f || u + v > 1f) return false;

        float d = invDet * Vector3.Dot(e2, q);
        if (d > EPS)
        {
            distance = d;
            hitPoint = ray.origin + ray.direction * d;
            return true;
        }
        return false;
    }
    #endregion

    void OnGUI()
    {
        // Runtime-only debug UI. Skip if disabled or not playing.
        if (!enableDebug || !Application.isPlaying) return;
        
        // Draw the main debug panel (using RefractionUtils helper functions)
        DrawDebugPanel();
        
        // Draw world-space labels (runtime-safe method; these are also safe in builds)
        foreach (var label in _worldLabels)
        {
            RefractionUtils.DrawWorldLabel(label.Item1, label.Item2, label.Item3);
        }
    }

    /// <summary>
    /// Populate _worldLabels from the current debug state so the labels can be rendered in OnGUI (runtime)
    /// Uses small arc radii to match the on-screen gizmo visuals.
    /// </summary>
    private void UpdateWorldLabels()
    {
        _worldLabels.Clear();

        if (!debugHasHit) return;

        // We use small arc radii consistent with gizmo arcs earlier
        const float arcR = 0.2f;
        const float gap = 0.03f;

        // i₁ (incident angle at entry)
        Vector3 inc = -debugInitialRayDirection;
        float i1 = Vector3.Angle(inc, debugEntryNormal);
        _worldLabels.Add((debugEntryHitPoint + inc * (arcR + gap), $"i₁={i1:F1}°", Color.green));

        // r₁ (refracted angle inside)
        Vector3 r1v = debugRefractedDirection;
        float r1 = Vector3.Angle(r1v, -debugEntryNormal);
        _worldLabels.Add((debugEntryHitPoint + r1v * (arcR * 0.8f + gap), $"r₁={r1:F1}°", Color.cyan));

        // i₂ and r₂ / TIR at exit
        if (debugHasExit)
        {
            Vector3 inc2 = -debugRefractedDirection;
            float i2 = Vector3.Angle(inc2, debugExitNormal);
            _worldLabels.Add((debugExitHitPoint + inc2 * (arcR + gap), $"i₂={i2:F1}°", Color.yellow));

            // r₂ (only for non-TIR)
            if (!debugExitIsTIR)
            {
                Vector3 r2v = debugFinalRayDirection;
                float r2 = Vector3.Angle(r2v, -debugExitNormal);
                _worldLabels.Add((debugExitHitPoint + r2v * (arcR * 1.2f + gap), $"r₂={r2:F1}°", Color.magenta));
            }

            // Deviation between incoming and final outgoing direction
            float dev = Vector3.Angle(debugInitialRayDirection, debugFinalRayDirection);
            Vector3 devDir = Quaternion.LookRotation(debugInitialRayDirection) * Quaternion.Euler(0, -dev / 2f, 0) * Vector3.forward;
            _worldLabels.Add((debugExitHitPoint + devDir * (arcR * 1.5f + 0.05f), $"Dev={dev:F1}°", Color.white));

            // TIR labels if applicable
            if (debugExitIsTIR)
            {
                _worldLabels.Add((debugExitHitPoint + (inc2 + debugFinalRayDirection).normalized * 0.3f, "TIR", Color.red));
                float criticalAngle = Mathf.Asin(1f / indexOfRefraction) * Mathf.Rad2Deg;
                _worldLabels.Add((debugExitHitPoint + debugExitNormal * 0.2f, $"θc={criticalAngle:F1}°", Color.yellow));
            }
        }
    }

    /// <summary>
    /// Build up a debug panel string using RefractionUtils helpers and draw it.
    /// This is only rendered at runtime when enableDebugText is true.
    /// </summary>
    private void DrawDebugPanel()
    {
        if (!enableDebugText || !Application.isPlaying) return;

        float width = 450;
        float height = 400;
        float margin = 10;
        Rect bgRect = new Rect(margin, margin, width, height);

        // Build content string (replacing previous DrawTextWithOutline usage)
        System.Text.StringBuilder sb = new System.Text.StringBuilder();

        if (debugHasHit)
        {
            sb.AppendLine($"ENTRY POINT: {debugEntryHitPoint:F3}");
            sb.AppendLine($"Normal: {debugEntryNormal:F3}");
            sb.AppendLine($"Inside Dir: {debugRefractedDirection:F3}");
            sb.AppendLine(RefractionUtils.FormatAngleInfo("i₁", debugEntryAngleI1, "r₁", debugEntryAngleR1));
            sb.AppendLine(RefractionUtils.FormatSnellsLaw(1f, debugEntryAngleI1, indexOfRefraction, debugEntryAngleR1));
            sb.AppendLine();

            if (debugHasExit)
            {
                sb.AppendLine($"EXIT POINT: {debugExitHitPoint:F3}");
                sb.AppendLine($"Normal: {debugExitNormal:F3}");

                if (debugExitIsTIR)
                {
                    sb.AppendLine($"TIR: i₂({debugExitAngleI2:F1}°) > θc({debugCriticalAngle:F1}°)");
                }
                else
                {
                    sb.AppendLine(RefractionUtils.FormatAngleInfo("i₂", debugExitAngleI2, "r₂", debugExitAngleR2));
                    sb.AppendLine(RefractionUtils.FormatSnellsLaw(indexOfRefraction, debugExitAngleI2, 1f, debugExitAngleR2));
                }
                sb.AppendLine();
            }

            if (enableDispersion)
            {
                sb.AppendLine("DISPERSION:");
                sb.AppendLine($"IOR Range: {debugDispersionMinIOR:F3} to {debugDispersionMaxIOR:F3}");
                sb.AppendLine($"Rays: {dispersionRayCount} (Red={debugDispersionMinIOR:F3}, Green={indexOfRefraction:F3}, Violet={debugDispersionMaxIOR:F3})");
            }
        }
        else
        {
            sb.AppendLine("No prism intersection");
        }

        // Draw using RefractionUtils helper (it will use its default text style if none provided)
        RefractionUtils.DrawDebugPanel(bgRect, "Prism Raycaster", sb.ToString());
    }

    void OnDrawGizmos()
    {
        // Editor/Play-mode gizmos for visual debugging. Skip when disabled or not playing.
        if (!enableDebug || !Application.isPlaying) return;

        // Prism wireframe (drawn in the mesh's local space)
        if (prismMeshFilter != null && prismMeshFilter.sharedMesh != null)
        {
            Gizmos.color  = new Color(0f,1f,1f,0.5f);
            Gizmos.matrix = prismMeshFilter.transform.localToWorldMatrix;
            Gizmos.DrawWireMesh(prismMeshFilter.sharedMesh);
            Gizmos.matrix = Matrix4x4.identity;
        }

        // Source point & forward direction
        Gizmos.color = Color.white;
        Gizmos.DrawSphere(transform.position, 0.02f);
        Gizmos.DrawLine(transform.position, transform.position + transform.forward * 0.5f);

        if (!debugHasHit) return;

        // Entry visual helpers
        RefractionUtils.DrawHitPoint(debugEntryHitPoint, Color.yellow);
        RefractionUtils.DrawNormal(debugEntryHitPoint, debugEntryNormal);
        RefractionUtils.DrawDirection(debugEntryHitPoint, debugRefractedDirection);

        if (!debugHasExit) return;

        // Line between entry and exit
        Gizmos.color = Color.white;
        Gizmos.DrawLine(debugEntryHitPoint, debugExitHitPoint);

        // Exit visual helpers
        RefractionUtils.DrawHitPoint(debugExitHitPoint, Color.magenta);
        RefractionUtils.DrawNormal(debugExitHitPoint, debugExitNormal);
        RefractionUtils.DrawDirection(debugExitHitPoint, debugFinalRayDirection, 0.5f, debugExitIsTIR ? Color.red : Color.white);

        #if UNITY_EDITOR
        // Angle arcs & editor-only labels (handles). Note: world-space text labels are provided at runtime by UpdateWorldLabels.
        const float arcR = 0.2f;

        // i₁ (incident angle at entry)
        Vector3 inc = -debugInitialRayDirection;
        float i1 = Vector3.Angle(inc, debugEntryNormal);
        RefractionUtils.DrawAngleArc(debugEntryHitPoint, inc, debugEntryNormal, i1, arcR, Color.green);

        // r₁ (refracted inside)
        Vector3 r1v = debugRefractedDirection;
        float r1 = Vector3.Angle(r1v, -debugEntryNormal);
        RefractionUtils.DrawAngleArc(debugEntryHitPoint, r1v, -debugEntryNormal, r1, arcR * 0.8f, Color.cyan);

        // i₂ (incident at exit)
        Vector3 inc2 = -debugRefractedDirection;
        float i2 = Vector3.Angle(inc2, debugExitNormal);
        RefractionUtils.DrawAngleArc(debugExitHitPoint, inc2, debugExitNormal, i2, arcR, Color.yellow);

        // r₂ (only for non-TIR)
        if (!debugExitIsTIR)
        {
            Vector3 r2v = debugFinalRayDirection;
            float r2 = Vector3.Angle(r2v, -debugExitNormal);
            RefractionUtils.DrawAngleArc(debugExitHitPoint, r2v, -debugExitNormal, r2, arcR * 1.2f, Color.magenta);
        }

        // Deviation arc between original and final direction
        float dev = Vector3.Angle(debugInitialRayDirection, debugFinalRayDirection);
        RefractionUtils.DrawAngleArc(debugExitHitPoint, debugInitialRayDirection, debugFinalRayDirection, dev, arcR * 1.5f, Color.white);

        // TIR Visualization (editor-only handles) — show reflection arc if TIR occurred
        if (debugExitIsTIR)
        {
            float reflectionAngle = 180f - 2 * i2;
            Handles.color = new Color(1, 0.5f, 0); // Orange
            Handles.DrawWireArc(debugExitHitPoint, Vector3.Cross(inc2, debugExitNormal), inc2, reflectionAngle, arcR * 1.4f);
        }
        #endif
    }
}
