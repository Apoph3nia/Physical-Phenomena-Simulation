using UnityEngine;
using TMPro;
using UnityEngine.UI;
using System.Collections;
using UnityEngine.Networking;
using System.Text;
using System.Collections.Generic;

/// <summary>
/// Manages the AI assistant chat interface, handles user input, sends requests to a Hugging Face model,
/// and displays the AI's response. It also gathers context from the active physics simulation to inform the AI.
/// </summary>
public class AIAssistant : MonoBehaviour
{
    [Header("API Configuration")]
    [Tooltip("The endpoint URL for the chat completions API.")]
    public string chatEndpoint = "https://router.huggingface.co/v1/chat/completions";
    [Tooltip("Your Hugging Face API key.")]
    public string apiKey = "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";
    
    [Header("Model Selection")]
    [Tooltip("The specific model to be used for generating responses.")]
    public string model = "meta-llama/Llama-3.1-8B-Instruct";
    
    [Header("UI References")]
    [Tooltip("The input field where the user types their message.")]
    public TMP_InputField userInputField;
    [Tooltip("The button that submits the user's question.")]
    public Button submitButton;
    [Tooltip("The TextMeshPro component that displays the chat history.")]
    public TMP_Text responseText;
    [Tooltip("The RectTransform of the content area within the scroll view.")]
    public RectTransform contentTransform;
    [Tooltip("The ScrollRect component for the chat display.")]
    public ScrollRect scrollRect;
    
    [Header("Simulation Root")]
    [Tooltip("The root GameObject of the current simulation. The assistant will search for simulation components on this object.")]
    public GameObject simulationObject;
    
    [Header("UI Settings")]
    [Tooltip("The speed at which the AI's response is typed out.")]
    public float typewriterSpeed = 0.05f;
    [Tooltip("The color for user messages in the chat.")]
    public Color userMessageColor = new Color(0.2f, 0.6f, 1f);
    [Tooltip("The color for AI messages in the chat.")]
    public Color aiMessageColor = new Color(0.1f, 0.8f, 0.3f);
    
    [Header("Model Settings")]
    [Tooltip("The maximum number of tokens the model should generate.")]
    public int maxTokens = 500;
    [Tooltip("Controls the randomness of the model's output. Lower values are more deterministic.")]
    [Range(0f, 1f)]
    public float temperature = 0.7f;
    [Tooltip("The maximum number of messages to include in the chat history sent to the model.")]
    public int chatHistoryLimit = 10;
    
    // Stores the history of the conversation.
    private readonly List<ChatMessage> chatHistory = new List<ChatMessage>();
    // Flag to prevent multiple requests from being sent simultaneously.
    private bool isProcessing;
    
    /// <summary>
    /// Called when the script instance is being loaded.
    /// Sets up UI event listeners and adds the initial greeting message.
    /// </summary>
    void Start()
    {
        if (submitButton != null) submitButton.onClick.AddListener(SubmitQuestion);
        if (userInputField != null)
        {
            // Allow submitting with the Enter key.
            userInputField.onEndEdit.AddListener((text) =>
            {
                if (Input.GetKeyDown(KeyCode.Return) && !isProcessing)
                    SubmitQuestion();
            });
        }
        AddMessage("system", "Hi, I'm your Optics Assistant. How could I help you?");
    }
    
    /// <summary>
    /// Called by the submit button or when the user presses Enter.
    /// It retrieves the user's question and starts the processing coroutine.
    /// </summary>
    public void SubmitQuestion()
    {
        if (userInputField == null) return;
        if (string.IsNullOrWhiteSpace(userInputField.text) || isProcessing) return;
        
        string question = userInputField.text;
        userInputField.text = ""; // Clear the input field
        StartCoroutine(ProcessQuestion(question));
    }
    
    /// <summary>
    /// The main coroutine that handles the entire process of getting an AI response.
    /// 1. Adds the user's message to the chat.
    /// 2. Builds a context string from the current simulation state.
    /// 3. Constructs the API request with system prompt, chat history, and the new question.
    /// 4. Sends the request to the Hugging Face API.
    /// 5. Handles the API response, including errors.
    /// 6. Displays the response using a typewriter effect.
    /// </summary>
    private IEnumerator ProcessQuestion(string question)
    {
        isProcessing = true;
        AddMessage("user", question);
        string context = BuildDebugContext();

        // Define the system prompt that guides the AI's behavior.
        var messages = new List<ChatMessage>
        {
            new ChatMessage
            {
                role = "system",
                content = "You are an expert optics assistant with deep knowledge of physics principles. Your task is to explain prism and water/obj refraction behavior in physics simulations. Use clear, concise language and include relevant physics principles in your explanations. Focus on being educational, accurate, and helpful. Do not use special characters or subscripts (e.g., use n1, n2 instead of n₁, n₂)."
            }
        };

        // Add recent chat history to the request, respecting the defined limit.
        int historyStartIndex = Mathf.Max(0, chatHistory.Count - chatHistoryLimit);
        for (int i = historyStartIndex; i < chatHistory.Count; i++)
        {
            messages.Add(chatHistory[i]);
        }
        
        // Add the current user question along with the simulation context.
        messages.Add(new ChatMessage { role = "user", content = $"Context: {context}\n\nQuestion: {question}" });

        // Create the request payload.
        var chatRequest = new ChatRequest
        {
            model = model,
            messages = messages,
            max_tokens = maxTokens,
            temperature = temperature,
            stream = false // We are not using streaming responses in this implementation.
        };

        string jsonBody = JsonUtility.ToJson(chatRequest);
        byte[] rawData = Encoding.UTF8.GetBytes(jsonBody);
        string responseContent = null;

        // Send the web request to the API.
        using (UnityWebRequest request = new UnityWebRequest(chatEndpoint, "POST"))
        {
            request.uploadHandler = new UploadHandlerRaw(rawData);
            request.downloadHandler = new DownloadHandlerBuffer();
            request.SetRequestHeader("Content-Type", "application/json");
            request.SetRequestHeader("Authorization", $"Bearer {apiKey}");
            request.timeout = 60; // Set a timeout for the request.
            yield return request.SendWebRequest();
            
            if (request.result == UnityWebRequest.Result.Success)
            {
                try
                {
                    // Attempt to parse the JSON response.
                    ChatResponse response = JsonUtility.FromJson<ChatResponse>(request.downloadHandler.text);
                    if (response.choices != null && response.choices.Count > 0 && !string.IsNullOrEmpty(response.choices[0].message.content))
                    {
                        responseContent = response.choices[0].message.content;
                    }
                    else
                    {
                        AddMessage("assistant", "I couldn't process that response. Please try again.");
                    }
                }
                catch (System.Exception e)
                {
                    Debug.LogError("JSON Parsing Error: " + e.Message);
                    AddMessage("assistant", "Error parsing response. Please check the console.");
                }
            }
            else
            {
                // Handle API errors based on the response code.
                string errorDetails = request.downloadHandler.text;
                Debug.LogError("API Error: " + errorDetails);
                
                if (request.responseCode == 400) AddMessage("assistant", $"Bad Request (400).");
                else if (request.responseCode == 401) AddMessage("assistant", "Authentication failed.");
                else if (request.responseCode == 429) AddMessage("assistant", "Too many requests.");
                else if (request.responseCode == 403) AddMessage("assistant", "Access denied.");
                else AddMessage("assistant", $"Error: {request.error} (Code: {request.responseCode})");
            }
        }

        // If a valid response was received, display it.
        if (!string.IsNullOrEmpty(responseContent))
        {
            yield return StartCoroutine(TypewriterResponse(responseContent));
        }

        isProcessing = false;
    }
    
    
    /// <summary>
    /// Builds a context string by checking for specific simulation components on the `simulationObject`.
    /// This provides the AI with real-time data from the active simulation.
    /// </summary>
    /// <returns>A formatted string containing the current state of the simulation.</returns>
    private string BuildDebugContext()
    {
        if (simulationObject == null)
            return "No simulation assigned. Please drag a simulation GameObject into the assistant's 'Simulation Root' field.";

        // Check which simulation component is attached to the root object.
        var prismOnRoot = simulationObject.GetComponent<PrismRaycaster>();
        if (prismOnRoot != null)
        {
            return "SIMULATION: Prism (Simulation 1)\n" + BuildPrismContext(prismOnRoot);
        }

        var objOnRoot = simulationObject.GetComponent<ObjectRefraction>();
        if (objOnRoot != null)
        {
            return "SIMULATION: WaterCup (Simulation 2)\n" + BuildObjectContext(objOnRoot);
        }

        return $"The assigned GameObject '{simulationObject.name}' does not have a PrismRaycaster or ObjectRefraction component attached.";
    }
    
    /// <summary>
    /// Gathers and formats the current state of the prism simulation.
    /// </summary>
    /// <param name="prism">The PrismRaycaster component to get data from.</param>
    /// <returns>A formatted string of prism simulation data.</returns>
    private string BuildPrismContext(PrismRaycaster prism)
    {
        if (prism == null) return "Prism simulation not assigned.";
        
        StringBuilder sb = new StringBuilder();
        sb.AppendLine("### Current Prism Simulation Data ###");
        
        if (prism.debugHasHit)
        {
            sb.AppendLine($"Entry Point: {prism.debugEntryHitPoint}");
            sb.AppendLine($"Entry Normal: {prism.debugEntryNormal}");
            sb.AppendLine($"Refracted Direction: {prism.debugRefractedDirection}");
            sb.AppendLine($"Incidence Angle: {prism.debugEntryAngleI1:F1}°");
            sb.AppendLine($"Refraction Angle: {prism.debugEntryAngleR1:F1}°");
            
            if (prism.debugHasExit)
            {
                sb.AppendLine();
                sb.AppendLine($"Exit Point: {prism.debugExitHitPoint}");
                sb.AppendLine($"Exit Normal: {prism.debugExitNormal}");
                sb.AppendLine($"Final Direction: {prism.debugFinalRayDirection}");
                sb.AppendLine($"Incidence Angle 2: {prism.debugExitAngleI2:F1}°");
                
                if (prism.debugExitIsTIR)
                {
                    sb.AppendLine($"TIR Occurred (Critical Angle: {prism.debugCriticalAngle:F1}°)");
                }
                else
                {
                    sb.AppendLine($"Refraction Angle 2: {prism.debugExitAngleR2:F1}°");
                }
                
                sb.AppendLine();
                sb.AppendLine($"Dispersion Enabled: {prism.enableDispersion}");
                
                if (prism.enableDispersion)
                {
                    sb.AppendLine($"IOR Range: {prism.debugDispersionMinIOR:F3} - {prism.debugDispersionMaxIOR:F3}");
                }
            }
        }
        else
        {
            sb.AppendLine("No prism intersection detected.");
        }
        
        return sb.ToString();
    }
    
    /// <summary>
    /// Gathers and formats the current state of the object refraction simulation.
    /// </summary>
    /// <param name="obj">The ObjectRefraction component to get data from.</param>
    /// <returns>A formatted string of object simulation data.</returns>
    private string BuildObjectContext(ObjectRefraction obj)
    {
        if (obj == null) return "Object refraction simulation not assigned.";
        
        StringBuilder sb = new StringBuilder();
        sb.AppendLine("### Current Object/Water Refraction Simulation Data ###");
        sb.AppendLine($"Object Length: {obj.objLength:F2}");
        sb.AppendLine($"Index Air: {obj.indexOfRefractionAir:F3}");
        sb.AppendLine($"Index Water: {obj.indexOfRefractionWater:F3}");
        sb.AppendLine();
        
        if (obj.HasIntersection)
        {
            sb.AppendLine($"Intersection Point: {obj.IntersectionPoint}");
            sb.AppendLine($"Angle of Incidence: {obj.IncidentAngle:F1}°");
            sb.AppendLine($"Angle of Refraction: {obj.RefractedAngle:F1}°");
        }
        else
        {
            sb.AppendLine("No intersection between obj and water plane detected.");
        }
        
        if (obj.waterPhysics != null)
        {
            sb.AppendLine($"Water Surface Y: {obj.waterPhysics.WaterSurfaceY:F3}");
        }
        
        return sb.ToString();
    }
    
    /// <summary>
    /// Adds a message to the chat history and triggers a UI update.
    /// </summary>
    /// <param name="role">The role of the message sender (e.g., "user", "assistant", "system").</param>
    /// <param name="content">The text content of the message.</param>
    private void AddMessage(string role, string content)
    {
        chatHistory.Add(new ChatMessage { role = role, content = content });
        UpdateChatDisplay();
    }
    
    /// <summary>
    /// Displays the AI's response character by character to create a typewriter effect.
    /// </summary>
    /// <param name="message">The full message to be displayed.</param>
    private IEnumerator TypewriterResponse(string message)
    {
        // Add a placeholder for the assistant's message.
        chatHistory.Add(new ChatMessage { role = "assistant", content = "" });
        int messageIndex = chatHistory.Count - 1;

        string baseText = BuildChatHistoryText(messageIndex);
        string prefix = $"<color=#{ColorUtility.ToHtmlStringRGB(aiMessageColor)}>Optics Assistant:</color> ";
        
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < message.Length; i++)
        {
            sb.Append(message[i]);
            responseText.text = baseText + prefix + sb.ToString();
            
            // Manually update layout and scroll position for better performance during typing.
            float preferredHeight = responseText.preferredHeight;
            float viewportHeight = scrollRect.viewport.rect.height;
            contentTransform.sizeDelta = new Vector2(contentTransform.sizeDelta.x, Mathf.Max(preferredHeight, viewportHeight));
            scrollRect.verticalNormalizedPosition = 0f; // Scroll to bottom

            yield return new WaitForSeconds(typewriterSpeed);
        }
        
        // Once typing is complete, update the history with the full message and refresh the display.
        chatHistory[messageIndex] = new ChatMessage { role = "assistant", content = message };
        responseText.text = baseText + prefix + message + "\n\n";
        UpdateChatDisplay();
    }
    
    /// <summary>
    /// Rebuilds the entire chat display from the chat history.
    /// </summary>
    private void UpdateChatDisplay()
    {
        responseText.text = BuildChatHistoryText(chatHistory.Count);
        UpdateChatLayout();
        StartCoroutine(ScrollToBottom());
    }
    
    /// <summary>
    /// Constructs the full, formatted chat history as a single string.
    /// </summary>
    /// <param name="messageCount">The number of messages from history to include.</param>
    /// <returns>A formatted string with colors and roles.</returns>
    private string BuildChatHistoryText(int messageCount)
    {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < messageCount; i++)
        {
            ChatMessage msg = chatHistory[i];
            string formattedMessage = "";
            switch (msg.role)
            {
                case "user":
                    formattedMessage = $"<color=#{ColorUtility.ToHtmlStringRGB(userMessageColor)}>You:</color> {msg.content}\n\n";
                    break;
                case "assistant":
                    formattedMessage = $"<color=#{ColorUtility.ToHtmlStringRGB(aiMessageColor)}>Optics Assistant:</color> {msg.content}\n\n";
                    break;
                case "system":
                    formattedMessage = $"<i>{msg.content}</i>\n\n";
                    break;
            }
            sb.Append(formattedMessage);
        }
        return sb.ToString();
    }
    
    /// <summary>
    /// Adjusts the height of the chat content area to fit the text.
    /// </summary>
    private void UpdateChatLayout()
    {
        float preferredHeight = responseText.preferredHeight;
        float viewportHeight = scrollRect.viewport.rect.height;
        // Ensure the content area is at least as tall as the viewport.
        contentTransform.sizeDelta = new Vector2(
            contentTransform.sizeDelta.x,
            Mathf.Max(preferredHeight, viewportHeight)
        );
    }
    
    /// <summary>
    /// Coroutine to scroll the chat view to the very bottom.
    /// Waits until the end of the frame to ensure layout calculations are complete.
    /// </summary>
    private IEnumerator ScrollToBottom()
    {
        yield return new WaitForEndOfFrame();
        scrollRect.verticalNormalizedPosition = 0f;
    }
    
    #region JSON Data Structures
    // These classes define the structure of the JSON data sent to and received from the API.
    // They are marked as [System.Serializable] so Unity's JsonUtility can work with them.

    [System.Serializable]
    private class ChatRequest
    {
        public string model;
        public List<ChatMessage> messages;
        public int max_tokens;
        public float temperature;
        public bool stream;
    }

    [System.Serializable]
    private class ChatMessage
    {
        public string role;
        public string content;
    }
    
    [System.Serializable]
    private class ChatResponse
    {
        public List<Choice> choices;
    }
    
    [System.Serializable]
    private class Choice
    {
        public ChatMessage message;
    }
    #endregion
}
