// Utility class for handling refraction calculations and debug visualizations in Unity
#if UNITY_EDITOR
using UnityEditor;
#endif
using UnityEngine;

public static class RefractionUtils
{
    private static GUIStyle _labelStyleWhite;
    private static GUIStyle _labelStyleOutline;

    // Initialize GUI styles for text rendering
    static RefractionUtils()
    {
        // Create white text style for main label
        _labelStyleWhite = new GUIStyle
        {
            normal = { textColor = Color.white },
            fontSize = 36,
            fontStyle = FontStyle.Bold,
            alignment = TextAnchor.MiddleCenter
        };

        // Create black outline style based on white style
        _labelStyleOutline = new GUIStyle(_labelStyleWhite)
        {
            normal = { textColor = Color.black }
        };
    }

    // Calculate refracted vector based on incident vector, normal, and refractive indices
    public static bool TryRefract(Vector3 incident, Vector3 normal, float n1, float n2, out Vector3 refracted)
    {
        // Normalize incident vector to ensure unit length
        incident.Normalize();
        // Calculate cosine of incident angle
        float cosI = Vector3.Dot(normal, incident);
        // Flip normal if incident ray is on same side
        if (cosI > 0) { normal = -normal; }
        else { cosI = -cosI; }
        // Compute refractive index ratio
        float eta = n1 / n2;
        // Calculate sine squared of transmitted angle
        float sinT2 = eta * eta * (1 - cosI * cosI);
        // Check for total internal reflection
        if (sinT2 > 1f)
        { 
            refracted = Vector3.zero; 
            return false; 
        }
        // Calculate cosine of transmitted angle
        float cosT = Mathf.Sqrt(1 - sinT2);
        // Compute refracted vector using Snell's law
        refracted = eta * incident + (eta * cosI - cosT) * normal;
        return true;
    }

    // Draw a text label in world space at the specified position
    public static void DrawWorldLabel(Vector3 worldPos, string text, Color color)
    {
        // Exit if main camera is missing
        if (Camera.main == null) return;
        // Only draw during repaint event
        if (Event.current != null && Event.current.type != EventType.Repaint) return;

        // Convert world position to screen coordinates
        Vector3 screenPos = Camera.main.WorldToScreenPoint(worldPos);
        // Skip if point is behind camera
        if (screenPos.z < 0) return;

        // Define label dimensions
        float size = 200f; // fixed pixel width
        Rect labelRect = new Rect(screenPos.x - size / 2f, Screen.height - screenPos.y - 15f, size, 30f);

        // Draw 1-pixel outline by rendering text at four offset positions
        GUI.Label(new Rect(labelRect.x - 1, labelRect.y, labelRect.width, labelRect.height), text, _labelStyleOutline);
        GUI.Label(new Rect(labelRect.x + 1, labelRect.y, labelRect.width, labelRect.height), text, _labelStyleOutline);
        GUI.Label(new Rect(labelRect.x, labelRect.y - 1, labelRect.width, labelRect.height), text, _labelStyleOutline);
        GUI.Label(new Rect(labelRect.x, labelRect.y + 1, labelRect.width, labelRect.height), text, _labelStyleOutline);

        // Draw main colored text
        GUIStyle mainStyle = new GUIStyle(_labelStyleWhite);
        mainStyle.normal.textColor = color;
        GUI.Label(labelRect, text, mainStyle);
    }

    // Draw a small sphere at the specified point (Editor-only)
    public static void DrawHitPoint(Vector3 point, Color color, float size = 0.02f)
    {
        Gizmos.color = color;
        Gizmos.DrawSphere(point, size);
    }

    // Draw a normal vector from a point (Editor-only)
    public static void DrawNormal(Vector3 point, Vector3 normal, float length = 0.25f, Color color = default)
    {
        if (color == default) color = Color.blue;
        Gizmos.color = color;
        Gizmos.DrawLine(point, point + normal * length);
    }

    // Draw a direction vector from a point (Editor-only)
    public static void DrawDirection(Vector3 point, Vector3 direction, float length = 0.5f, Color color = default)
    {
        if (color == default) color = Color.cyan;
        Gizmos.color = color;
        Gizmos.DrawLine(point, point + direction.normalized * length);
    }

    // Draw an arc to visualize an angle (Editor-only)
    public static void DrawAngleArc(Vector3 center, Vector3 fromDir, Vector3 normal, float angle, float radius, Color color)
    {
#if UNITY_EDITOR
        Handles.color = color;
        Vector3 cross = Vector3.Cross(fromDir, normal);
        Handles.DrawWireArc(center, cross, fromDir, angle, radius);
#endif
    }

    // Draw a debug panel with title and content in the specified rectangle
    public static void DrawDebugPanel(Rect rect, string title, string content, GUIStyle textStyle = null, GUIStyle bgStyle = null)
    {
        // Draw background if style provided
        if (bgStyle != null)
        {
            GUI.Box(rect, GUIContent.none, bgStyle);
        }

        // Use default text style if none provided
        if (textStyle == null)
        {
            textStyle = new GUIStyle { normal = { textColor = Color.white }, fontSize = 24, fontStyle = FontStyle.Bold };
        }

        // Render title and content
        GUI.Label(rect, title + "\n" + content, textStyle);
    }

    // Format Snell's law equation as a string
    public static string FormatSnellsLaw(float n1, float theta1, float n2, float theta2)
    {
        return $"{n1:F2} * sin({theta1:F1}°) = {n2:F2} * sin({theta2:F1}°)";
    }

    // Format angle information for display
    public static string FormatAngleInfo(string labelI, float angleI, string labelR, float angleR)
    {
        return $"{labelI}: {angleI:F1}°  {labelR}: {angleR:F1}°";
    }
}