using UnityEngine;

[RequireComponent(typeof(Collider))]
public class WaterPhysics : MonoBehaviour
{
    [Tooltip("Enable or disable the floating effect for all objects in this water volume.")]
    public bool isFloatingEffectActive = true;

    [Tooltip("The strength of the buoyant force at 1 unit of depth.")]
    public float buoyancyStrength = 15f;

    [Tooltip("The strength of the water's linear damping.")]
    public float waterLinearDamping = 1f;

    [Tooltip("How strongly to counter gravity while object is sinking in water.")]
    [Range(0f, 1f)]
    public float gravityReductionInWater = 0.5f;

    [Tooltip("How quickly water damping blends in after entry.")]
    public float dampingBlendSpeed = 2f;

    public float WaterSurfaceY { get; private set; }

    private Renderer rend;

    private void Awake()
    {
        rend = GetComponent<Renderer>();
        UpdateWaterSurfaceY();
    }

    private void Update()
    {
        UpdateWaterSurfaceY();
    }

    private void UpdateWaterSurfaceY()
    {
        if (rend != null)
        {
            WaterSurfaceY = rend.bounds.max.y;
        }
    }

    private void OnTriggerStay(Collider other)
    {
        if (!isFloatingEffectActive) return;

        Rigidbody rb = other.attachedRigidbody;
        if (rb != null)
        {
            // Smoothly blend linear damping so entry slows
            rb.linearDamping = Mathf.Lerp(rb.linearDamping, waterLinearDamping, Time.deltaTime * dampingBlendSpeed);

            // Depth from water surface (positive if submerged)
            float depth = WaterSurfaceY - rb.worldCenterOfMass.y;

            // Apply proportional buoyancy if submerged
            if (depth > 0f)
            {
                float force = buoyancyStrength * depth;
                rb.AddForce(Vector3.up * force, ForceMode.Acceleration);
            }

            // Reduce gravity effect when moving downward in water
            if (rb.linearVelocity.y < 0f)
            {
                rb.AddForce(-Physics.gravity * gravityReductionInWater, ForceMode.Acceleration);
            }
        }
    }

    private void OnTriggerExit(Collider other)
    {
        Rigidbody rb = other.attachedRigidbody;
        if (rb != null)
        {
            // Reset damping when leaving water
            rb.linearDamping = 0f;
        }
    }

    void OnValidate()
    {
        Collider col = GetComponent<Collider>();
        if (col != null && !col.isTrigger)
        {
            col.isTrigger = true;
            Debug.LogWarning("Collider on " + name + " has been set to 'Is Trigger'. This is required for WaterPhysics to work.", this);
        }
    }
}
