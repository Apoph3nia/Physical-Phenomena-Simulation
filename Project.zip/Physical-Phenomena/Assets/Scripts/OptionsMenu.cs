using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class OptionsMenu : MonoBehaviour
{
    [Header("Material Options")]
    [SerializeField] private Material material1;
    [SerializeField] private Material material2;
    [SerializeField] private Renderer targetRenderer;

    [Header("Dispersion Control")]
    [SerializeField] private Slider dispersionSlider;
    [SerializeField] private PrismRaycaster dispersionScript;
    [SerializeField] private TextMeshProUGUI dispersionValueText;

    private void Start()
    {
        if (dispersionSlider != null && dispersionScript != null)
        {
            dispersionSlider.value = dispersionScript.dispersionStrength;
            dispersionSlider.onValueChanged.AddListener(SetDispersionStrength);
        }

        // Initialize text
        UpdateDispersionValueText(dispersionSlider.value);
    }

    public void ApplyMaterial1()
    {
        if (targetRenderer != null && material1 != null)
            targetRenderer.material = material1;
    }

    public void ApplyMaterial2()
    {
        if (targetRenderer != null && material2 != null)
            targetRenderer.material = material2;
    }

    public void SetDispersionStrength(float value)
    {
        if (dispersionScript != null)
            dispersionScript.dispersionStrength = value;

        UpdateDispersionValueText(value);
    }

    private void UpdateDispersionValueText(float value)
    {
        if (dispersionValueText != null)
            dispersionValueText.text = value.ToString("F2"); // 2 decimals
    }
}
