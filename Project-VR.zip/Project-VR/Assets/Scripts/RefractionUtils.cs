// Utility class for handling refraction calculations and debug visualizations in Unity
using UnityEngine;

public static class RefractionUtils
{
    // Calculate refracted vector based on incident vector, normal, and refractive indices
    public static bool TryRefract(Vector3 incident, Vector3 normal, float n1, float n2, out Vector3 refracted)
    {
        // Normalize incident vector to ensure unit length
        incident.Normalize();
        // Calculate cosine of incident angle
        float cosI = Vector3.Dot(normal, incident);
        // Flip normal if incident ray is on same side
        if (cosI > 0) { normal = -normal; }
        else { cosI = -cosI; }
        // Compute refractive index ratio
        float eta = n1 / n2;
        // Calculate sine squared of transmitted angle
        float sinT2 = eta * eta * (1 - cosI * cosI);
        // Check for total internal reflection
        if (sinT2 > 1f)
        { 
            refracted = Vector3.zero; 
            return false; 
        }
        // Calculate cosine of transmitted angle
        float cosT = Mathf.Sqrt(1 - sinT2);
        // Compute refracted vector using Snell's law
        refracted = eta * incident + (eta * cosI - cosT) * normal;
        return true;
    }

    public static string FormatSnellsLaw(float n1, float theta1, float n2, float theta2, string colorTheta1, string colorTheta2)
    {
        return $"{n1:F2} * sin(<color={colorTheta1}>{theta1:F1}째</color>) = {n2:F2} * sin(<color={colorTheta2}>{theta2:F1}째</color>)";
    }

    // Format angle information for display
    public static string FormatAngleInfo(string labelI, float angleI, string labelR, float angleR)
    {
        return $"{labelI}: {angleI:F1}째  {labelR}: {angleR:F1}째";
    }
}