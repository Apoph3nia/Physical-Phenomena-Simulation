using UnityEngine;
using UnityEngine.EventSystems;
using TMPro;

[AddComponentMenu("Utils/Editor Camera Controller")]
[RequireComponent(typeof(Camera))]
public class EditorCameraController : MonoBehaviour
{
    [Header("Pause Menu")]
    public GameObject PAUSE_MENU_UI;
    private bool isPaused = false;

    [Header("Movement")]
    public float moveSpeed = 6f;
    public float boostMultiplier = 2f;

    [Header("Look")]
    public float lookSpeed = 5f;
    public KeyCode toggleCursorKey = KeyCode.Escape;

    [Header("Drag & Rotate Settings")]
    public float rotationSpeed = 50f;

    [Header("Cursor Crosshair")]
    public Texture2D crosshairDefaultTexture;
    public Texture2D crosshairDragTexture;
    public Texture2D crosshairReleaseTexture;
    public Vector2 crosshairSize = new Vector2(32, 32);

    // Component refs
    private Camera _cam;
    private Transform _camTransform;

    // State
    private Transform _selectedObject;
    private Vector3 _dragOffset;
    private Vector3 _dragScreenPosition;
    private bool _justReleased;
    private bool _wasCursorLocked;
    private float _yaw;
    private float _pitch;

    // Cursor & init
    private bool _cursorLocked = true;           // start with camera control active
    private bool _initializedCursor = false;     // force initial lock on first Update

    void Start()
    {
        _cam = GetComponent<Camera>();
        _camTransform = transform;
        _yaw = _camTransform.eulerAngles.y;
        _pitch = _camTransform.eulerAngles.x;

        // Ensure EventSystem exists for UI focus detection
        if (EventSystem.current == null)
        {
            var go = new GameObject("EventSystem", typeof(EventSystem), typeof(StandaloneInputModule));
            DontDestroyOnLoad(go);
        }

        // Start unpaused with pause UI hidden, camera controls active
        isPaused = false;
        if (PAUSE_MENU_UI != null) PAUSE_MENU_UI.SetActive(false);

        _cursorLocked = true;
        SetCursorState(_cursorLocked);

        // Ensure game runs at normal speed on Start
        Time.timeScale = 1f;
    }

    void Update()
    {
        // Force the cursor state on very first frame (fixes editor oddities)
        if (!_initializedCursor)
        {
            SetCursorState(_cursorLocked);
            _initializedCursor = true;
        }

        // Toggle pause / pause UI with Escape (works even when paused)
        if (Input.GetKeyDown(toggleCursorKey) && _selectedObject == null)
        {
            TogglePauseMenu();
        }

        // If paused, don't run camera/drag logic (Escape handling done above)
        if (isPaused) return;

        _justReleased = false;

        // If UI input field is focused, ignore camera/drag behavior
        if (IsMouseOverUI()) return;

        HandleObjectSelection();
        HandleCameraControls();
        HandleMovement();
    }

    private void HandleObjectSelection()
    {
        if (Input.GetMouseButtonDown(0))
        {
            Ray ray = _cam.ScreenPointToRay(Input.mousePosition);
            if (Physics.Raycast(ray, out var hit))
            {
                var collider = hit.collider;

                if (hit.transform.CompareTag("Box"))
                    return;

                if (collider is BoxCollider || collider is MeshCollider || collider is SphereCollider)
                {
                    _wasCursorLocked = _cursorLocked;
                    _cursorLocked = true;
                    SetCursorState(true);

                    Transform objectToSelect = hit.transform;
                    if (objectToSelect.parent != null && objectToSelect.parent.CompareTag("WaterCup"))
                    {
                        objectToSelect = objectToSelect.parent;
                    }
                    _selectedObject = objectToSelect;

                    var hitPoint = hit.point;
                    _dragScreenPosition = _cam.WorldToScreenPoint(hitPoint);
                    _dragOffset = _selectedObject.position - hitPoint;

                    // If it has a rigidbody, stop its motion and disable gravity while dragging
                    var rb = _selectedObject.GetComponent<Rigidbody>();
                    if (rb != null)
                    {
                        if (!rb.isKinematic)
                        {
                            rb.linearVelocity = Vector3.zero;
                            rb.angularVelocity = Vector3.zero;
                        }
                        rb.useGravity = false;
                    }
                }
            }
        }

        if (Input.GetMouseButtonUp(0) && _selectedObject != null)
        {
            // Re-enable gravity on release
            var rb = _selectedObject.GetComponent<Rigidbody>();
            if (rb != null)
            {
                rb.useGravity = true;
                // keep linearVelocity zero so it doesn't immediately slam
                if (!rb.isKinematic)
                {
                    rb.linearVelocity = Vector3.zero;
                    rb.angularVelocity = Vector3.zero;
                }
            }

            _selectedObject = null;
            _justReleased = true;
            _cursorLocked = _wasCursorLocked;
            SetCursorState(_cursorLocked);
        }
    }

    private void HandleCameraControls()
    {
        // Toggle cursor lock when pressing the key and no object selected
        if (Input.GetKeyDown(toggleCursorKey) && _selectedObject == null)
        {
            _cursorLocked = !_cursorLocked;
            SetCursorState(_cursorLocked);
        }

        if (_selectedObject != null && Input.GetMouseButton(0))
        {
            var rb = _selectedObject.GetComponent<Rigidbody>();
            if (rb != null)
            {
                // Prevent momentum accumulation on non-kinematic rigidbodies
                if (!rb.isKinematic)
                {
                    rb.linearVelocity = Vector3.zero;
                    rb.angularVelocity = Vector3.zero;
                }
                // make the object weightless while being dragged so physics doesn't fight us
                rb.useGravity = false;
            }

            if (Input.GetKey(KeyCode.LeftControl))
            {
                // Rotate selected object
                _selectedObject.Rotate(_camTransform.up, Input.GetAxis("Mouse X") * rotationSpeed * Time.deltaTime, Space.World);
                _selectedObject.Rotate(_camTransform.right, -Input.GetAxis("Mouse Y") * rotationSpeed * Time.deltaTime, Space.World);
            }
            else
            {
                // Rotate camera while dragging (so you can change view)
                UpdateCameraRotation();
            }

            Vector3 newWorldPoint = _cam.ScreenToWorldPoint(_dragScreenPosition);
            Vector3 newPosition = newWorldPoint + _dragOffset;

            if (rb != null)
                rb.MovePosition(newPosition);
            else
                _selectedObject.position = newPosition;
        }
        else if (_cursorLocked)
        {
            UpdateCameraRotation();
        }
    }

    private void UpdateCameraRotation()
    {
        _yaw += lookSpeed * Input.GetAxis("Mouse X");
        _pitch -= lookSpeed * Input.GetAxis("Mouse Y");
        _pitch = Mathf.Clamp(_pitch, -89f, 89f);
        _camTransform.rotation = Quaternion.Euler(_pitch, _yaw, 0f);
    }

    private void HandleMovement()
    {
        Vector3 input = new Vector3(
            Input.GetAxis("Horizontal"),
            Input.GetKey(KeyCode.E) ? 1 : Input.GetKey(KeyCode.Q) ? -1 : 0,
            Input.GetAxis("Vertical")
        );
        Vector3 move = _camTransform.TransformDirection(input);
        float speed = moveSpeed * (Input.GetKey(KeyCode.LeftShift) ? boostMultiplier : 1f);
        CharacterController controller = GetComponent<CharacterController>();
        controller.Move(move * speed * Time.deltaTime);

    }

    private bool IsMouseOverUI()
    {
        if (EventSystem.current == null) return false;
        var sel = EventSystem.current.currentSelectedGameObject;
        return sel != null && sel.GetComponent<TMP_InputField>() != null;
    }

    void OnGUI()
    {
        // Draw crosshair only when not paused and when cursor is locked (camera-control mode)
        if (isPaused || !_cursorLocked) return;

        Texture2D toDraw = GetCrosshairTexture();
        if (toDraw != null)
        {
            Vector2 center = new Vector2((Screen.width - crosshairSize.x) / 2f, (Screen.height - crosshairSize.y) / 2f);
            GUI.DrawTexture(new Rect(center.x, center.y, crosshairSize.x, crosshairSize.y), toDraw);
        }
    }

    private Texture2D GetCrosshairTexture()
    {
        if (_selectedObject != null && Input.GetMouseButton(0))
            return crosshairDragTexture;
        if (_justReleased)
            return crosshairReleaseTexture;
        return crosshairDefaultTexture;
    }

    void SetCursorState(bool locked)
    {
        Cursor.visible = !locked;
        Cursor.lockState = locked ? CursorLockMode.Locked : CursorLockMode.None;
    }

    public void TogglePauseMenu()
    {
        if (!isPaused)
        {
            // Pause the game
            isPaused = true;
            if (PAUSE_MENU_UI != null) PAUSE_MENU_UI.SetActive(true);
            _cursorLocked = false;
            SetCursorState(_cursorLocked);

            Time.timeScale = 0f;
        }
        else
        {
            // Resume the game
            isPaused = false;
            if (PAUSE_MENU_UI != null) PAUSE_MENU_UI.SetActive(false);

            // Instead of locking immediately, keep cursor visible until click
            _cursorLocked = false;
            SetCursorState(_cursorLocked);

            Time.timeScale = 1f;
        }
    }
}
